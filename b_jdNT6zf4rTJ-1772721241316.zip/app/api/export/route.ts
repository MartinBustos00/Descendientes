import { NextResponse } from "next/server"
import fs from "fs"
import path from "path"
import * as XLSX from "xlsx"
import type { Person } from "@/lib/types"

const DATA_FILE = path.join(process.cwd(), "data", "persons.json")

function readPersons(): Person[] {
  if (!fs.existsSync(DATA_FILE)) {
    return []
  }
  const raw = fs.readFileSync(DATA_FILE, "utf-8")
  return JSON.parse(raw) as Person[]
}

export async function GET() {
  try {
    const persons = readPersons()

    const excelData = persons.map((p) => ({
      Nombre: p.nombre,
      Apellido: p.apellido,
      "Numero de DNI": p.dni,
      Edad: p.edad,
      Email: p.email,
      "Telefono": p.telefono,
      "Direccion": p.direccion,
      Ciudad: p.ciudad,
      "Fecha de Nacimiento": p.fechaNacimiento,
      Notas: p.notas,
      "Fecha de Registro": new Date(p.fechaRegistro).toLocaleDateString("es-ES"),
    }))

    const workbook = XLSX.utils.book_new()
    const worksheet = XLSX.utils.json_to_sheet(excelData)

    // Auto-size columns
    const colWidths = Object.keys(excelData[0] || {}).map((key) => ({
      wch: Math.max(
        key.length,
        ...excelData.map((row) => String(row[key as keyof typeof row] || "").length)
      ) + 2,
    }))
    worksheet["!cols"] = colWidths

    XLSX.utils.book_append_sheet(workbook, worksheet, "Miembros")

    const buffer = XLSX.write(workbook, { type: "buffer", bookType: "xlsx" })

    return new NextResponse(buffer, {
      headers: {
        "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "Content-Disposition": `attachment; filename="miembros_${new Date().toISOString().split("T")[0]}.xlsx"`,
      },
    })
  } catch {
    return NextResponse.json(
      { error: "Error al exportar datos" },
      { status: 500 }
    )
  }
}
