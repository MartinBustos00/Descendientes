import { NextResponse } from "next/server"
import fs from "fs"
import path from "path"
import type { Person } from "@/lib/types"

const DATA_FILE = path.join(process.cwd(), "data", "persons.json")

function ensureDataDir() {
  const dir = path.dirname(DATA_FILE)
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true })
  }
  if (!fs.existsSync(DATA_FILE)) {
    fs.writeFileSync(DATA_FILE, JSON.stringify([], null, 2))
  }
}

function readPersons(): Person[] {
  ensureDataDir()
  const raw = fs.readFileSync(DATA_FILE, "utf-8")
  return JSON.parse(raw) as Person[]
}

function writePersons(persons: Person[]) {
  ensureDataDir()
  fs.writeFileSync(DATA_FILE, JSON.stringify(persons, null, 2))
}

export async function GET() {
  try {
    const persons = readPersons()
    return NextResponse.json(persons)
  } catch {
    return NextResponse.json([], { status: 200 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const persons = readPersons()

    const newPerson: Person = {
      id: crypto.randomUUID(),
      nombre: body.nombre?.trim() || "",
      apellido: body.apellido?.trim() || "",
      dni: body.dni?.trim() || "",
      edad: body.edad?.trim() || "",
      email: body.email?.trim() || "",
      telefono: body.telefono?.trim() || "",
      direccion: body.direccion?.trim() || "",
      ciudad: body.ciudad?.trim() || "",
      fechaNacimiento: body.fechaNacimiento || "",
      notas: body.notas?.trim() || "",
      fechaRegistro: new Date().toISOString(),
    }

    if (!newPerson.nombre || !newPerson.apellido) {
      return NextResponse.json(
        { error: "Nombre y Apellido son obligatorios" },
        { status: 400 }
      )
    }

    persons.push(newPerson)
    writePersons(persons)

    return NextResponse.json(newPerson, { status: 201 })
  } catch {
    return NextResponse.json(
      { error: "Error al registrar la persona" },
      { status: 500 }
    )
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")

    if (!id) {
      return NextResponse.json({ error: "ID es obligatorio" }, { status: 400 })
    }

    const persons = readPersons()
    const filtered = persons.filter((p) => p.id !== id)

    if (filtered.length === persons.length) {
      return NextResponse.json(
        { error: "Persona no encontrada" },
        { status: 404 }
      )
    }

    writePersons(filtered)
    return NextResponse.json({ success: true })
  } catch {
    return NextResponse.json(
      { error: "Error al eliminar la persona" },
      { status: 500 }
    )
  }
}
