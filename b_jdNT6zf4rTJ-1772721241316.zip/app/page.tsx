"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { HeroBanner } from "@/components/hero-banner"
import { RegistrationForm } from "@/components/registration-form"
import { MembersTable } from "@/components/members-table"

export default function Home() {
  const [refreshKey, setRefreshKey] = useState(0)

  function handlePersonAdded() {
    setRefreshKey((k) => k + 1)
  }

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <Header />
      <HeroBanner />
      <main className="mx-auto flex w-full max-w-7xl flex-col gap-8 px-4 py-8 sm:px-6 lg:px-8">
        <RegistrationForm onPersonAdded={handlePersonAdded} />
        <MembersTable refreshKey={refreshKey} />
      </main>
      <footer className="mt-auto border-t border-border bg-card py-6">
        <div className="mx-auto max-w-7xl px-4 text-center sm:px-6 lg:px-8">
          <p className="text-sm text-muted-foreground">
            Descendientes de Victoria &mdash; Creados para buenas obras
          </p>
        </div>
      </footer>
    </div>
  )
}
