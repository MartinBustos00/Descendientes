export interface Person {
  id: string
  nombre: string
  apellido: string
  dni: string
  edad: string
  email: string
  telefono: string
  direccion: string
  ciudad: string
  fechaNacimiento: string
  notas: string
  fechaRegistro: string
}
