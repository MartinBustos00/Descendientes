"use client"

import { useState } from "react"
import { toast } from "sonner"
import useSWR from "swr"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Download, Search, Trash2, Users } from "lucide-react"
import type { Person } from "@/lib/types"

const fetcher = (url: string) => fetch(url).then((r) => r.json())

interface MembersTableProps {
  refreshKey: number
}

export function MembersTable({ refreshKey }: MembersTableProps) {
  const [search, setSearch] = useState("")
  const { data: persons = [], mutate } = useSWR<Person[]>(
    `/api/persons?r=${refreshKey}`,
    fetcher,
    { revalidateOnFocus: true }
  )

  const filtered = persons.filter((p) => {
    const query = search.toLowerCase()
    return (
      p.nombre.toLowerCase().includes(query) ||
      p.apellido.toLowerCase().includes(query) ||
      p.dni.toLowerCase().includes(query) ||
      p.email.toLowerCase().includes(query) ||
      p.telefono.toLowerCase().includes(query) ||
      p.ciudad.toLowerCase().includes(query)
    )
  })

  async function handleDelete(id: string) {
    try {
      const res = await fetch(`/api/persons?id=${id}`, { method: "DELETE" })
      if (!res.ok) throw new Error("Error al eliminar")
      toast.success("Persona eliminada")
      mutate()
    } catch {
      toast.error("Error al eliminar la persona")
    }
  }

  async function handleExport() {
    try {
      const res = await fetch("/api/export")
      if (!res.ok) throw new Error("Error al exportar")

      const blob = await res.blob()
      const url = URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = `miembros_${new Date().toISOString().split("T")[0]}.xlsx`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)

      toast.success("Archivo Excel descargado")
    } catch {
      toast.error("Error al exportar los datos")
    }
  }

  return (
    <Card className="border-border bg-card">
      <CardHeader className="pb-4">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <CardTitle className="flex items-center gap-2 font-serif text-xl text-card-foreground">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-accent">
              <Users className="h-4 w-4 text-accent-foreground" />
            </div>
            Miembros Registrados
            <span className="ml-1 rounded-full bg-primary px-2.5 py-0.5 text-xs font-medium text-primary-foreground">
              {persons.length}
            </span>
          </CardTitle>
          <Button
            onClick={handleExport}
            variant="outline"
            className="flex items-center gap-2 border-accent text-accent-foreground hover:bg-accent/20"
            disabled={persons.length === 0}
          >
            <Download className="h-4 w-4" />
            Exportar Excel
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="mb-4 flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Buscar por nombre, apellido, DNI, email, telefono o ciudad..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
            <Users className="mb-3 h-12 w-12 opacity-30" />
            <p className="text-sm">
              {persons.length === 0
                ? "No hay miembros registrados"
                : "No se encontraron resultados"}
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto rounded-lg border border-border">
            <Table>
              <TableHeader>
                <TableRow className="bg-secondary hover:bg-secondary">
                  <TableHead className="text-secondary-foreground font-semibold">Nombre</TableHead>
                  <TableHead className="text-secondary-foreground font-semibold">Apellido</TableHead>
                  <TableHead className="text-secondary-foreground font-semibold hidden sm:table-cell">
                    DNI
                  </TableHead>
                  <TableHead className="text-secondary-foreground font-semibold hidden sm:table-cell">
                    Edad
                  </TableHead>
                  <TableHead className="text-secondary-foreground font-semibold hidden md:table-cell">
                    Email
                  </TableHead>
                  <TableHead className="text-secondary-foreground font-semibold hidden sm:table-cell">
                    Telefono
                  </TableHead>
                  <TableHead className="text-secondary-foreground font-semibold hidden lg:table-cell">
                    Ciudad
                  </TableHead>
                  <TableHead className="text-secondary-foreground font-semibold hidden lg:table-cell">
                    Fecha Registro
                  </TableHead>
                  <TableHead className="text-secondary-foreground font-semibold text-right">
                    Acciones
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((person) => (
                  <TableRow key={person.id}>
                    <TableCell className="font-medium text-card-foreground">
                      {person.nombre}
                    </TableCell>
                    <TableCell className="text-card-foreground">{person.apellido}</TableCell>
                    <TableCell className="hidden text-muted-foreground sm:table-cell">
                      {person.dni || "-"}
                    </TableCell>
                    <TableCell className="hidden text-muted-foreground sm:table-cell">
                      {person.edad || "-"}
                    </TableCell>
                    <TableCell className="hidden text-muted-foreground md:table-cell">
                      {person.email || "-"}
                    </TableCell>
                    <TableCell className="hidden text-muted-foreground sm:table-cell">
                      {person.telefono || "-"}
                    </TableCell>
                    <TableCell className="hidden text-muted-foreground lg:table-cell">
                      {person.ciudad || "-"}
                    </TableCell>
                    <TableCell className="hidden text-muted-foreground lg:table-cell">
                      {new Date(person.fechaRegistro).toLocaleDateString(
                        "es-ES"
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-8 w-8 p-0 text-destructive hover:bg-destructive/10 hover:text-destructive"
                          >
                            <Trash2 className="h-4 w-4" />
                            <span className="sr-only">Eliminar</span>
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>
                              Eliminar miembro
                            </AlertDialogTitle>
                            <AlertDialogDescription>
                              Esta seguro que desea eliminar a{" "}
                              <strong>
                                {person.nombre} {person.apellido}
                              </strong>
                              ? Esta accion no se puede deshacer.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancelar</AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => handleDelete(person.id)}
                              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                            >
                              Eliminar
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
