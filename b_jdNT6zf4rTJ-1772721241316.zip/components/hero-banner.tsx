import Image from "next/image"

export function HeroBanner() {
  return (
    <section className="relative overflow-hidden bg-primary py-12 sm:py-16">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(212,169,53,0.15)_0%,_transparent_70%)]" />
      <div className="relative mx-auto flex max-w-7xl flex-col items-center gap-6 px-4 text-center sm:px-6 lg:px-8">
        <Image
          src="/images/logo.png"
          alt="Descendientes de Victoria - Logo"
          width={140}
          height={140}
          className="rounded-full shadow-xl shadow-primary/30"
          priority
        />
        <div>
          <h1 className="font-serif text-3xl font-bold tracking-tight text-primary-foreground sm:text-4xl lg:text-5xl text-balance">
            Descendientes de Victoria
          </h1>
          <p className="mt-2 text-lg text-primary-foreground/80 sm:text-xl">
            Creados para buenas obras
          </p>
        </div>
        <p className="max-w-2xl text-sm leading-relaxed text-primary-foreground/60 sm:text-base">
          Sistema de registro de miembros. Registre nuevas personas y gestione
          la base de datos de la comunidad con facilidad.
        </p>
      </div>
    </section>
  )
}
