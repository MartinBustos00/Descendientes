"use client"

import Image from "next/image"
import Link from "next/link"
import { Users } from "lucide-react"

export function Header() {
  return (
    <header className="bg-primary text-primary-foreground">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6 lg:px-8">
        <Link href="/" className="flex items-center gap-3">
          <Image
            src="/images/logo.png"
            alt="Descendientes de Victoria"
            width={48}
            height={48}
            className="rounded-full"
          />
          <div className="hidden sm:block">
            <h1 className="text-lg font-bold leading-tight tracking-tight text-primary-foreground">
              Descendientes de Victoria
            </h1>
            <p className="text-xs text-primary-foreground/70">
              Creados para buenas obras
            </p>
          </div>
        </Link>
        <nav className="flex items-center gap-2">
          <Link
            href="/"
            className="flex items-center gap-2 rounded-lg bg-primary-foreground/10 px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary-foreground/20"
          >
            <Users className="h-4 w-4" />
            <span className="hidden sm:inline">Registro</span>
          </Link>
        </nav>
      </div>
    </header>
  )
}
