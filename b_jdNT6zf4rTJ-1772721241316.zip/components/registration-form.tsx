"use client"

import { useState } from "react"
import { toast } from "sonner"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { UserPlus } from "lucide-react"

interface RegistrationFormProps {
  onPersonAdded: () => void
}

export function RegistrationForm({ onPersonAdded }: RegistrationFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [formData, setFormData] = useState({
    nombre: "",
    apellido: "",
    dni: "",
    edad: "",
    email: "",
    telefono: "",
    direccion: "",
    ciudad: "",
    fechaNacimiento: "",
    notas: "",
  })

  function handleChange(
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) {
    setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }))
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()

    if (!formData.nombre.trim() || !formData.apellido.trim()) {
      toast.error("Nombre y Apellido son obligatorios")
      return
    }

    setIsSubmitting(true)

    try {
      const res = await fetch("/api/persons", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      })

      if (!res.ok) {
        const data = await res.json()
        throw new Error(data.error || "Error al registrar")
      }

      toast.success("Persona registrada exitosamente")
      setFormData({
        nombre: "",
        apellido: "",
        dni: "",
        edad: "",
        email: "",
        telefono: "",
        direccion: "",
        ciudad: "",
        fechaNacimiento: "",
        notas: "",
      })
      onPersonAdded()
    } catch (err) {
      toast.error(
        err instanceof Error ? err.message : "Error al registrar la persona"
      )
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Card className="border-border bg-card">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2 font-serif text-xl text-card-foreground">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
            <UserPlus className="h-4 w-4 text-primary-foreground" />
          </div>
          Registrar Persona
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="nombre" className="text-card-foreground">
                Nombre <span className="text-destructive">*</span>
              </Label>
              <Input
                id="nombre"
                name="nombre"
                placeholder="Ingrese el nombre"
                value={formData.nombre}
                onChange={handleChange}
                required
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="apellido" className="text-card-foreground">
                Apellido <span className="text-destructive">*</span>
              </Label>
              <Input
                id="apellido"
                name="apellido"
                placeholder="Ingrese el apellido"
                value={formData.apellido}
                onChange={handleChange}
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="dni" className="text-card-foreground">
                Numero de DNI
              </Label>
              <Input
                id="dni"
                name="dni"
                placeholder="Ingrese el numero de DNI"
                value={formData.dni}
                onChange={handleChange}
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="edad" className="text-card-foreground">
                Edad
              </Label>
              <Input
                id="edad"
                name="edad"
                type="number"
                min="0"
                max="150"
                placeholder="Ingrese la edad"
                value={formData.edad}
                onChange={handleChange}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="email" className="text-card-foreground">
                Correo Electronico
              </Label>
              <Input
                id="email"
                name="email"
                type="email"
                placeholder="correo@ejemplo.com"
                value={formData.email}
                onChange={handleChange}
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="telefono" className="text-card-foreground">
                Telefono
              </Label>
              <Input
                id="telefono"
                name="telefono"
                type="tel"
                placeholder="+1 234 567 8900"
                value={formData.telefono}
                onChange={handleChange}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="direccion" className="text-card-foreground">
                Direccion
              </Label>
              <Input
                id="direccion"
                name="direccion"
                placeholder="Calle, numero, colonia"
                value={formData.direccion}
                onChange={handleChange}
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="ciudad" className="text-card-foreground">
                Ciudad
              </Label>
              <Input
                id="ciudad"
                name="ciudad"
                placeholder="Ciudad o municipio"
                value={formData.ciudad}
                onChange={handleChange}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="fechaNacimiento" className="text-card-foreground">
                Fecha de Nacimiento
              </Label>
              <Input
                id="fechaNacimiento"
                name="fechaNacimiento"
                type="date"
                value={formData.fechaNacimiento}
                onChange={handleChange}
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="notas" className="text-card-foreground">
                Notas
              </Label>
              <Input
                id="notas"
                name="notas"
                placeholder="Observaciones adicionales"
                value={formData.notas}
                onChange={handleChange}
              />
            </div>
          </div>

          <Button
            type="submit"
            disabled={isSubmitting}
            className="mt-2 w-full bg-primary text-primary-foreground hover:bg-primary/90 sm:w-auto sm:self-end"
          >
            {isSubmitting ? "Registrando..." : "Registrar Persona"}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
